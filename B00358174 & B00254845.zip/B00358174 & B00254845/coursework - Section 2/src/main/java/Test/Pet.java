

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 

/**
 *
 * @author Gary
 */
    public class Pet implements Comparable<Pet> {
        String pet_name;
   
    
        
         public Pet(String pet_name){
            this.pet_name = pet_name;
           
            }
         
         public String toString(){
            return "Pet name: "+ this.pet_name;
         }
         public int compareTo(Pet new_compare){
           int compare;
           compare = new_compare.pet_name.compareToIgnoreCase(this.pet_name);
           return compare;
       }
            }

        
    
        
    

