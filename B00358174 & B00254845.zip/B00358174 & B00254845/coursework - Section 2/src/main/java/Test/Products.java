/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Gary
 */
public class Products implements Comparable<Products>{
    String Product_name;
    String Product_code;
    int Stock_Levels;
    
    public Products(){
        boolean Valid_input = true;
        do{
        try{// gets user input to set product details
        this.Product_name = Input.getString("enter the name of the product your adding: ");
        this.Product_code = Input.getString("enter the product code: ");
        this.Stock_Levels = Input.getInteger("please enter the amount of stock youd like to add: ");
        Valid_input = true;
        }
        catch(IllegalArgumentException Invalid_input){
                System.out.println(" this is outside the range expected plese ensure you enter an integer number for stock levels");
                Valid_input = false;
        }
        
        }while(Valid_input !=true);
                
}   public String toString(){
            return "Product name: "+ this.Product_name + " Product code: "+Product_code+" Stock Levels: "+Stock_Levels;
         }
    public int compareTo(String Product_code, String Product_name){
           int compare;
           if(Product_code.compareToIgnoreCase(this.Product_code) == 0 && Product_name.compareToIgnoreCase(this.Product_name) == 0 ){
               return compare =0;
           }
           else{
            return compare = Product_code.compareToIgnoreCase(this.Product_code);
        }
    }

    @Override
    public int compareTo(Products o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

}
