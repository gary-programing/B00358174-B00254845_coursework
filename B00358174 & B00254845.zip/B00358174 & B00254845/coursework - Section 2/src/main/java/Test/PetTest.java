
import java.util.logging.Level;
import java.util.logging.Logger;





/**
 *
 * @author Gary
 */

public class PetTest {
    
      
    public static void main(String[] args) throws IllegalArgumentException {
        BST_Pets pet_store = new BST_Pets();
        LinkedListPetDetails Product_list = new LinkedListPetDetails();
        Integer option = null;
        Boolean valid=false;
     do {
         do{
         try{
            System.out.println("------  MENU  ------");
            System.out.println("Enter 1 to: add pet");
            System.out.println("Enter 2 to: Find pet products");
            System.out.println("Enter 3 to: Display pet details");
            System.out.println("Enter 4 to: delete pet details");
            System.out.println("Enter 5 to: Display all pet details");
            System.out.println("Enter 6 to: Add product to the system");
            System.out.println("Enter 7 to: find product in the system");
            System.out.println("Enter 8 to: Remove product from the system");
            System.out.println("Enter 9 to: Displays all products in the system");
            System.out.println("Enter 0 to: Quit");
            option = Input.getInteger("option: ");
           
            switch (option) {
                
                case 0:
                    System.out.println("Quitting program...");
                    break;
                case 1:
                   // adds a pet to the system
                    
                    String name = Input.getString("please enter the name of the pet you'd like to add: ");
                    Pet newpet = new Pet(name);
                    try{
                    pet_store.insert(newpet);
                    }
                    catch(SortedADT.NotUniqueException NotUnique){
                    System.out.println("pet already exists");
                    }
                    break;
                case 2:
                    //looks for a pet in the tree and displays if we sell products for that pet
                    String target = Input.getString("what pet are you looking for");
                    Pet Target = new Pet(target);
                    Comparable Target_found = null;
                    try{
                    Target_found = pet_store.find(Target);
                    }
                    catch(SortedADT.NotFoundException notFound){
                     System.out.println("sorry we don't hold stock on that pet at the moment");
                    }
                    if (Target_found != null){
                        System.out.println("we have Stock for that pet");
                    }
                            
                    break;
                case 3:
                    
                    // finds if we have a specific pet in stock and displays its details if we do
                    
                    String Target_display = Input.getString("what pet are you looking for"); 
                    Pet Target_Display = new Pet(Target_display);
                    Comparable Display_Target_found = null;
                    try{
                    Display_Target_found = pet_store.find(Target_Display);
                    if (Display_Target_found != null){
                        System.out.println("here are the details on this pet: "+Display_Target_found);
                    }
                    }
                    catch(SortedADT.NotFoundException notFound){
                     System.out.println("sorry we don't hold stock on that pet at the moment");
                    }
                   
                    break;

                case 4:
                    // removes a pet from the system
                    String Target_Delete = Input.getString("what pet are you looking to delete from the system: ");
                    Pet target_pet_delete = new Pet(Target_Delete);
                    System.out.println(target_pet_delete.toString());
                    Comparable target_delete_complete;
                    try{
                    target_delete_complete = pet_store.remove(target_pet_delete);
                    }
                    catch(SortedADT.NotFoundException notFound){
                     System.out.println("there are no records in the system on "+ Target_Delete);
                    }
                   
                    break;
                case 5:
                    System.out.println(pet_store.toString());
                    break;
                case 6:
                    Products new_Product = new Products();
                    try{
                    Product_list.insert(new_Product);
                    }
                    catch(SortedADT.NotUniqueException NotUnique){
                    System.out.println("Product already exists");
                    }
                    System.out.println("Your product has been added here are the details "+Product_list.toString());
                    break;
                case 7:
                    String Target_Product_Name =Input.getString("Please enter the name of the product you'd like to find: "); 
                    String Target_Product_Code =Input.getString("Please enter the product code you'd like to find: "); 
                    Comparable target_product_found = null;
                    try{
                    target_product_found = Product_list.find(Target_Product_Name, Target_Product_Code);
                    if (target_product_found!=null){
                        System.out.println("Your product has been found here are the details: "+target_product_found);
                    } 
                    //testing purposes print Product_list.current
                    }
                    catch(SortedADT.NotFoundException Not_Found){
                    System.out.println("Product cannot be found");
                    }
                        // testing purposes System.out.println(Product_list.toString());
                    break;
                case 8:
                    String Delete_Product_Name =Input.getString("Please enter the name of the product you'd like to remove: "); 
                    String Delete_Product_Code =Input.getString("Please enter the product code you'd like to find remove: "); 

                    try{
                    Product_list.remove(Delete_Product_Name, Delete_Product_Code);
                    }
                    catch(SortedADT.NotFoundException NotFound){
                    System.out.println("Product is not in the system");
                    }
                    // testing purposes System.out.println(Product_list.toString());
                    break;
                case 9:
                    System.out.println(Product_list.toString());
                    break;
                  default:
                    System.out.println("please enter a valid number from the menu");
            }
            
            valid = true;        
        }
    catch(IllegalArgumentException Invalid_input){
                System.out.println(" this is outside the range expected plese ensure you select an integer number from the menu ");
                valid = false;
         }   
        
             
         }while (valid == false);
     
     
    }while (option != 0);
    }

}

