/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Gary
 */
public class BST_PetsTest {
    
    public BST_PetsTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of add_node method, of class BST_Pets.
     */
    @Test
    public void testAdd_node() {
        System.out.println("add_node");
        String Name = "";
        Pet New_Pet = null;
        BST_Pets instance = new BST_Pets();
        instance.add_node(New_Pet);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
