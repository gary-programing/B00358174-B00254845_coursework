
import java.util.logging.Level;
import java.util.logging.Logger;





/**
 *
 * @author Gary
 */

public class PetTest {
    
      
    public static void main(String[] args) throws IllegalArgumentException {
        BST_Pets pet_store = new BST_Pets();
        Integer option = null;
        Boolean valid=false;
     do {
         do{
         try{
            System.out.println("------  MENU  ------");
            System.out.println("Enter 1 to: add pet");
            System.out.println("Enter 2 to: Find pet products");
            System.out.println("Enter 3 to: Display pet details as well as its products");
            System.out.println("Enter 4 to: delete pet details");
            System.out.println("Enter 5 to: Display all pet details and their product details");
            System.out.println("Enter 6 to: Add product to the system");
            System.out.println("Enter 7 to: Remove product from the system");
            System.out.println("Enter 8 to: Displays all products in the system");
            System.out.println("Enter 0 to: Quit");
            option = Input.getInteger("option: ");
           
            switch (option) {
                
                case 0:
                    System.out.println("Quitting program...");
                    break;
                case 1:
                   // adds a pet to the system
                    
                    String name = Input.getString("please enter the name of the pet you'd like to add: ");
                    Pet newpet = new Pet(name);
                    try{
                    pet_store.insert(newpet);
                    }
                    catch(SortedADT.NotUniqueException NotUnique){
                    System.out.println("pet already exists");
                    }
                    break;
                case 2:
                    //looks for a pet in the tree and displays if we sell products for that pet
                    String target = Input.getString("what pet are you looking for");
                    Pet Target = new Pet(target);
                    Comparable Target_found = null;
                    try{
                    Target_found = pet_store.find(Target);
                    }//catches if they target pet was not found and displays a messege
                    catch(SortedADT.NotFoundException notFound){
                     System.out.println("sorry we don't hold stock on that pet at the moment");
                    }
                    if (Target_found != null){
                        System.out.println("we have Stock for that pet");
                    }
                            
                    break;
                case 3:
                    
                    // finds if we have a specific pet in stock and displays its details as well as the product details for it
                    
                    String Target_display = Input.getString("what pet are you looking for"); 
                    Pet Target_Display = new Pet(Target_display);
                    pet_store.findAndDisplay(Target_Display);
                    break;

                case 4:
                    // removes a pet from the system
                    String Target_Delete = Input.getString("what pet are you looking to delete from the system: ");
                    Pet target_pet_delete = new Pet(Target_Delete);
                    System.out.println(target_pet_delete.toString());
                    Comparable target_delete_complete;
                    try{
                    target_delete_complete = pet_store.remove(target_pet_delete);
                    }
                    catch(SortedADT.NotFoundException notFound){
                     System.out.println("there are no records in the system on "+ Target_Delete);
                    }
                   
                    break;
                case 5:
                    // Displays all pets and their product details in alphabetical order
                    System.out.println(pet_store.toString());
                    break;
                case 6:
                    // searches the tree to find a pet if its found add a product to it's product list
                    String Target_pet_name = Input.getString("what pet are you looking for to add a product for");
                    Pet Target_pet = new Pet(Target_pet_name);
                    try{
                    pet_store.insert_Product(Target_pet);
                    }
                    catch(SortedADT.NotUniqueException NotUnique){
                    System.out.println("Product already exists");
                    }
                    break;
                   
                case 7:
                    // searches the tree for a pet and if found deletes a specific product from its list
                     String target_pet_product_deletion = Input.getString("what pet are you looking for to add a product for");
                    Pet Target_pet_product_deletion = new Pet(target_pet_product_deletion);
                    pet_store.remove_Product(Target_pet_product_deletion);
                    break;
                    
                case 8:
                    System.out.println(pet_store.Display_Pets_With_Products_In_Stock());
                    break;

                  default:
                    System.out.println("please enter a valid number from the menu");
            }

            
            valid = true;        
        }
         // makes sure that any input entered 
    catch(IllegalArgumentException Invalid_input){
                System.out.println(" this is outside the range expected plese ensure you select an integer number from the menu ");
                valid = false;
         }   
        
             
         }while (valid == false);
     
     
    }while (option != 0);
    }

}

