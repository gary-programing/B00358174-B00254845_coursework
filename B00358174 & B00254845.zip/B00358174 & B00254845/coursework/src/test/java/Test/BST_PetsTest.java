/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Gary
 */
public class BST_PetsTest {
    
    public BST_PetsTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of insert method, of class BST_Pets.
     */
    @Test
     void testInsert_Comparable() throws Exception {
        System.out.println("insert");
        Comparable object = null;
        BST_Pets instance = new BST_Pets();
        String New_Pet = "Cat";
        Pet new_pet = new Pet(New_Pet);
        instance.insert(new_pet);
        object = instance.find(new_pet);
        if(object != null){
            assertEquals("cat", object.toString());
        }
        else{
            fail("Failed to find cat");
        }
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
}
