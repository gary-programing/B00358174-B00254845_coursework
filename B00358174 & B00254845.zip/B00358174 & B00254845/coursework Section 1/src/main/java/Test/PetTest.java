
import java.util.logging.Level;
import java.util.logging.Logger;





/**
 *
 * @author Gary
 */

public class PetTest {
    
      
    public static void main(String[] args) throws IllegalArgumentException {
        BST_Pets pet_store = new BST_Pets();
        
        Integer option = null;
        Boolean valid=false;
     do {
         do{
         try{
            System.out.println("------  MENU  ------");
            System.out.println("1: add pet");
            System.out.println("2: Find pet products");
            System.out.println("3: Display pet details");
            System.out.println("4: delete pet details");
            System.out.println("5: Display all pet details");
            System.out.println("0: Quit");
            option = Input.getInteger("option: ");
           
            switch (option) {
                
                case 0:
                    System.out.println("Quitting program...");
                    break;
                case 1:
                   // adds a pet to the system
                    
                    String name = Input.getString("please enter the name of the pet you'd like to add: ");
                    Pet newpet = new Pet(name);
                    System.out.println(name);
                    System.out.println(newpet.toString());
                    try{
                    pet_store.insert(newpet);
                    }
                    catch(SortedADT.NotUniqueException NotUnique){
                    System.out.println("pet already exists");
                    }
                    break;
                case 2:
                    //looks for a pet in the tree and displays if we sell products for that pet
                    String target = Input.getString("what pet are you looking for");
                    Pet Target = new Pet(target);
                    System.out.println(Target.toString());
                    Comparable Target_found = null;
                    try{
                    Target_found = pet_store.find(Target);
                    }
                    catch(SortedADT.NotFoundException notFound){
                     System.out.println("sorry we don't hold stock on that pet at the moment");
                    }
                   
                            
                    break;
                case 3:
                    
                      // finds if we have a specific pet in stock and displays its details if we do
                    
                    String Target_display = Input.getString("what pet are you looking for"); 
                    Pet Target_Display = new Pet(Target_display);
                    Comparable Display_Target_found = null;
                    try{
                    Display_Target_found = pet_store.find(Target_Display);
                    if (Display_Target_found != null){
                        System.out.println("here are the details on this pet: "+Display_Target_found);
                    }
                    }
                    catch(SortedADT.NotFoundException notFound){
                     System.out.println("sorry we don't hold stock on that pet at the moment");
                    }
                   
                    break;

                case 4:
                    // removes a pet from the system
                    String Target_Delete = Input.getString("what pet are you looking to delete from the system: ");
                    Pet target_pet_delete = new Pet(Target_Delete);
                    System.out.println(target_pet_delete.toString());
                    Comparable target_delete_complete;
                    try{
                    target_delete_complete = pet_store.remove(target_pet_delete);
                    }
                    catch(SortedADT.NotFoundException notFound){
                     System.out.println("there are no records in the system on ");
                    }
                   
                    break;
                case 5:
                    System.out.println(pet_store.toString());
                    break;
                default:
                    System.out.println("please enter a valid number from the menu");
                    
                 
            }
            
            valid = true;        
        }
    catch(IllegalArgumentException Invalid_input){
                System.out.println(" this is outside the range expected plese ensure you select an integer number from the menu ");
                valid = false;
         }   
        
             
         }while (valid == false);
     
     
    }while (option != 0);
    }

}

