public class BST_Pets implements SortedADT {

    @Override
    public void insert(Comparable object) throws NotUniqueException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Comparable remove(Comparable object) throws NotFoundException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Comparable find(Comparable object) throws NotFoundException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    



    private class BST_Pets_Node {
        private Pet New_pet;
        private BST_Pets_Node left;
        private BST_Pets_Node right;
        
        
        BST_Pets_Node(Pet New_pet){
            this.New_pet = New_pet;
         
        }
       
    }
    private BST_Pets_Node root;
    private BST_Pets_Node current;
    private BST_Pets_Node parent;
     
    public String toString(){
        String treeDetails = new String();
        if (this.root != null) {
            System.out.println("-----Alphabetical Order-----");
            treeDetails+=this.getInOrder(this.root);
        }
        else{
            treeDetails+="tree is empty";
        }
        return treeDetails;
    }
    
    private String getInOrder(BST_Pets_Node current) {
        String inOrderDetails = new String();
        if (current != null) {
            inOrderDetails += this.getInOrder(current.right);
            inOrderDetails += current.New_pet + "  ";
            inOrderDetails += this.getInOrder(current.left);
        }
        return inOrderDetails;
    }
    
  
    // this section of code was taken and adapted from the labs and libary
    public void insert(Pet new_pet) throws NotUniqueException {
        /* Algorithm
            create a new tree node
            add the object to the new node
            if tree is empty then
                make root refer to the new node
            else
                insert the new node in the tree 
            end if
         */
        BST_Pets_Node newNode = new BST_Pets_Node(new_pet);
       
        if (this.root == null) {
            this.root = newNode;
        } else {
            this.insert(newNode,this.root);
        }
    }

    private void insert(BST_Pets_Node newNode,BST_Pets_Node current)
        throws NotUniqueException{
        /* Algorithm
            if new object matches current object then
                // attempt to add a duplicate
                throw not unique exception
            end if
            if new object is less than the current object then
                if current node does not have a left subtree then
                    make left of current the new node
                else
                    insert the new node in the left subtree
                end if
            else
                if current node does not have a right subtree then
                    make right of current the new node
                else
                    insert the new node in the right subtree
                end if
            end if
         end if
         */
       
        if (newNode.New_pet.compareTo(current.New_pet) == 0)
            throw new NotUniqueException();
        if (newNode.New_pet.compareTo(current.New_pet) < 0) {
            if (current.left == null) {
                current.left = newNode;
            } else {
                this.insert(newNode,current.left);
            }
        } else if (current.right == null) {
            current.right = newNode;
        } else {
            this.insert(newNode,current.right);
        }
    }
    
  
    
public Comparable find(Pet new_pet) throws NotFoundException {
        return this.find(new_pet, this.root);
    }

    private  Comparable find(Pet new_pet, BST_Pets_Node current) throws NotFoundException{
        
        
        Comparable Found = null;
        
        if (current != null) {
            if (new_pet.compareTo(current.New_pet) == 0) {
                this.current = current;
                Found = current.New_pet;
                
            } else {
                this.parent = current;
                if (new_pet.compareTo(current.New_pet) < 0) {
                    Found = this.find(new_pet, current.left);
                    
                } else {
                    Found = this.find(new_pet, current.right);
                    
                }
            }
        } else {
            throw new NotFoundException();
            
        }
        return Found;
        
    
    }
        public Comparable remove(Pet new_pet) throws NotFoundException {
        // sets up parent and current
        Comparable Removed_pet=this.find(new_pet);
        
        System.out.println(Removed_pet);
        if (this.current == null){
            this.replaceNode(null);
        }
        if (this.current.left == null && this.current.right == null) {
            this.replaceNode(null);
        } else if (this.current.left != null && this.current.right == null) {
            this.replaceNode(this.current.left);
            this.current.left = null;
        } else if (this.current.left == null && this.current.right != null) {
            this.replaceNode(this.current.right);
            this.current.right = null;
        } else {
            this.replaceWithNextLargest(this.current, this.current, this.current.right);
        }
        return Removed_pet;
    }

    private void replaceNode(BST_Pets_Node replacement) {
        /* algorithm
            if current is root then 
                set root to replacement node
            else
                if current is the root of the left subtree of parent then
                    set parent's left subtreee to replacement node
                else
                    set parent's right subtree to replacement node
                end if
            end if
            set current object to null
         */
        if (this.current == this.root) // removing root
            
        {
            System.out.println("root has been replaced with " + replacement.New_pet.toString());
            this.root = replacement;
            
        } else if(this.current == null){
            this.current = null;
            System.out.println("replaced with null");
        } else if (this.current == this.parent.left) {
            this.parent.left = replacement;
            System.out.println("replaced with left");
        } else {
            System.out.println("replaced with right");
            this.parent.right = replacement;
        }
        this.current.New_pet = null;
        
    }

    private void replaceWithNextLargest(BST_Pets_Node nodeForDeletion, BST_Pets_Node parent, BST_Pets_Node current) {
        /* Algorithm
            if current does not have a left subtree then
                copy the current object into the node for deletion
                if parent matches the node for deletion then
                    set parent's right subtree to be current's right subtree
                else
                    set parent's left subtree to be current's right subtree
                end if
                clear the current node
            else
                replace node for deletion with the next largest in current's left subtree
            end if
         */
        if (current.left == null) {
            nodeForDeletion.New_pet = current.New_pet;
            if (parent == nodeForDeletion) {
                parent.right = current.right;
            } else {
                parent.left = current.right;
            }
            current.New_pet = null;
            current.right = null;
        } else {
            this.replaceWithNextLargest(nodeForDeletion, current, current.left);
        }
    }


}


               
                         

                  
                
                
                
               
               
           
           
       
   
        
   
    
    
        
        
        
        
        
    
     
    

